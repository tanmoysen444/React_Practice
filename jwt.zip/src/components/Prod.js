import React from 'react'

function Prod() {
  return (
    <div>
        <h1>I m Products</h1>
    </div>
  )
}

export default Prod
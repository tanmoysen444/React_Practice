import React from 'react'

function ComponentB() {
  return (
    <div>ComponentB</div>
  )
}

export default ComponentB
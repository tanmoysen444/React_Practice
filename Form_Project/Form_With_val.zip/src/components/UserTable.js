import React from 'react'

function UserTable(props) {
 
  return (
   
    <div>
      <table border="1px" cellspacing="0px" cellPadding="10px">
        <tr><td>Username</td>
        <td>password</td></tr>
      </table>
      
      {props.formData.map((user, idx)=> {
            localStorage.setItem("user", JSON.stringify(user))

        return (
          <table border="1px" cellspacing="0px" cellPadding="10px" >
           
            <div key = {idx}>
              
              
                  
                <tr> <td> <h4>{user.username}</h4> </td>
                 <td> <h4>{user.password}</h4> </td>
                </tr>



                </div>
                </table>
        );
    })}
    </div>
  );
}

export default UserTable;
import React, {  useState } from 'react'

function UserForm(props) {
    const [userData, setuserData] = useState({
        username: "",
        password: "",
    });
    // console.log("userData",userData);

    const [usernameError, setusernameError] = useState("");
    const [passwordError, setPasswordError] = useState("");

    let updateUserData = (event) => {
        setuserData({
            ...userData,
            // it shows that the ui form field is connected vise versa with the sate in which the value is stored and will get updated
            [event.target.name]: event.target.value,
        });
    }

    const validateUsername = () => {
        if (userData.username) {
            let regex = /^\S+@\S+$/;
            if (regex.test(userData.username)) {
                setusernameError("");
                return true;
            } else {
                setusernameError("*Enter valid Username");
            }
        } else {
            setusernameError("*Username is Required");
        }
        return false;
    };

    //password validate
    const validatePassword = () => {
        if (userData.password) {
            let regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
            if (regex.test(userData.password)) {
                setPasswordError("");
                return true;
            } else {
                setPasswordError(`*Enter valid password,Minimum 8 characters, at least one letter and one number`);
            }
        } else {
            setPasswordError("*Password is Required");
        }
        return false;
    };

    let saveData = (event) => {
        validateUsername()
        validatePassword()
        // LocalStr()
        if (validateUsername() && validatePassword()) {
            props.getDataFromForm(userData);
            setuserData({
                username: "",
                password: "",
            });

            
            
        }
        // localStorage.setItem("userData", JSON.stringify(userData))
    };
    // let LocalStr=()=>{
    //     localStorage.setItem(userData,JSON.stringify(userData))
    // }
    
    //  in this place do all the validation for form if required
    // sending data to pafrent component
    // props.getDataFromForm(userData);


    // clearing the form after submit
    //     setuserData ({
    //         username:"",
    //         password:"",
    //     });
    // };
    return (
        <div>
            <h1>Login Form</h1>
            <input
                name="username"
                type="email"
                placeholder='Enter Email'
                value={userData.username}
                onChange={(event) => {
                    updateUserData(event);
                }}

            />
            {usernameError && <div className="errormsg">{usernameError}</div>}


            <input
                name='password'
                // type ="password" can also been done
                type="text"
                palceholder="Enter Password"
                value={userData.password}
                onChange={(event) => {
                    updateUserData(event);
                }}
            />
            {passwordError && <div className="errormsg">{passwordError}</div>}

            <button onClick={saveData}> Login</button>
        </div>
    )
}

export default UserForm;
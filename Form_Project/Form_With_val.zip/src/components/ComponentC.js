import React from 'react'

function ComponentC() {
  return (
    <div>ComponentC</div>
  )
}

export default ComponentC
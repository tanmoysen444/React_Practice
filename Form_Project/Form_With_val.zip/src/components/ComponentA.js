// create a Component.js file inside component foldser, the first letter should be in uppercase
//  first type snipet rfce to create functional component in Component file
import React from 'react'

function ComponentA() {
  return (
    <div>ComponentA</div>
  )
}

export default ComponentA

//  then export ComponentA to parent App.js which is inside src & go to App.js
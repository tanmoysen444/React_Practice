// import logo from './logo.svg'; here we are commenting logo because we have deleated the div components inside fn app() , so in terminal error will show & that is a minor
import { useState } from 'react';
import './App.css';
import ComponentA from './components/ComponentA';
import ComponentB from './components/ComponentB';
import ComponentC from './components/ComponentC';
import ComponentD from './components/ComponentD';
import UserForm from './components/UserForm';
import UserTable from './components/UserTable';

function App() {
  const [formData,setformData] = useState([])
  console.log("formData",formData);




  let getDataFromForm= (userData) => {
    // console.log("data in app " ,data);
    
    // for array if we need to push do the folowing
    let formDataCopy = [...formData];
    formDataCopy.push(userData);
    setformData(formDataCopy);
  };
  return (
    <div className="App">
      {/*  here inport by typing <ComnponentA /> which will import component A from component file */}
      {/* <ComponentA />
      <ComponentB />
      <ComponentC /> */}
      {/* all these component.js files are the childs of parent App.js */}
      {/* <ComponentD /> */}


      <UserForm getDataFromForm = {getDataFromForm} />
      <UserTable formData = {formData} />
    </div>
  );
}

export default App;

import React from 'react'

function Home() {
  return (
    <div>
        <h1>HOME</h1>
        <img src='assets/home_img.jpg' width="700px"/>
    </div>
  )
}

export default Home